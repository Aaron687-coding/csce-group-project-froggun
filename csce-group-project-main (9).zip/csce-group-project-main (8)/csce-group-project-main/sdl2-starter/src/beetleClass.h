#ifndef BEETLE_CLASS_H
#define BEETLE_CLASS_H

#include <SDL.h>
#include "frogClass.h"
#include "DefaultShotgun.h"

class healthBar;

class BeetleState {
private:
    SDL_Texture* beetleTexture;
    static const int MAX_BEETLES = 20;
    SDL_Rect beetleRect[MAX_BEETLES];
    int beetleCount = MAX_BEETLES;
    int beetleIndex = 0;
    Frog* frog;
    DefaultShotgun* gun;
    SDL_Renderer* renderer;

    bool clearBeetle[MAX_BEETLES];
    healthBar* beetleHpBar[MAX_BEETLES];

    const int beetleMaxHp = 40;
    int beetleWidth = 50;
    int beetleHeight = 50;

    // Damage cooldown variables
    float damageCooldown[MAX_BEETLES];
    const float damageInterval = 1.0f;

    // Spawning variables
    float spawnTimer = 0.0f;
    const float spawnInterval = 5.0f;

    // No need for isActive flag since we're checking pointers

public:
    void Init(SDL_Renderer* renderer, Frog* frogInstance, DefaultShotgun* gun);
    void setGun(DefaultShotgun* gun);
    void Update(float deltaTime);
    void Render(SDL_Renderer* renderer);
    void CleanUp(); // Ensure this is declared
};
#endif BEETLE_CLASS_H